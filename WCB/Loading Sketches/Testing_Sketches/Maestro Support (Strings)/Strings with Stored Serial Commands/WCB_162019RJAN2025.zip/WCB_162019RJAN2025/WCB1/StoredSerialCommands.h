#ifndef SerialCOmmands_h
#define SerialCOmmands_h

String CommandSequence1 = "MRS102*MRS201*;S2TESTSERIAL2";
String CommandSequence2 = "";
String CommandSequence3 = "";
String CommandSequence4 = "";
String CommandSequence5 = "";
String CommandSequence6 = "";
String CommandSequence7 = "";
String CommandSequence8 = "";
String CommandSequence9 = "";
String CommandSequence10 = "";
String CommandSequence11 = "";
String CommandSequence12 = "";
String CommandSequence13 = "";
String CommandSequence14 = "";
String CommandSequence15 = "";
String CommandSequence16 = "";
String CommandSequence17 = "";
String CommandSequence18 = "";
String CommandSequence19 = "";
String CommandSequence20 = "";
String CommandSequence21 = "";
String CommandSequence22 = "";
String CommandSequence23 = "";
String CommandSequence24 = "";
String CommandSequence25 = "";
String CommandSequence26 = "";
String CommandSequence27 = "";
String CommandSequence28 = "";
String CommandSequence29 = "";
String CommandSequence30 = "";
String CommandSequence31 = "";
String CommandSequence32 = "";
String CommandSequence33 = "";
String CommandSequence34 = "";
String CommandSequence35 = "";
String CommandSequence36 = "";
String CommandSequence37 = "";
String CommandSequence38 = "";
String CommandSequence39 = "";
String CommandSequence40 = "";
String CommandSequence41 = "";
String CommandSequence42 = "";
String CommandSequence43 = "";
String CommandSequence44 = "";
String CommandSequence45 = "";
String CommandSequence46 = "";
String CommandSequence47 = "";
String CommandSequence48 = "";
String CommandSequence49 = "";
String CommandSequence50 = "MRS102*;S1TESTSER1*MRS201*TESTINGBROADCAST";


#endif