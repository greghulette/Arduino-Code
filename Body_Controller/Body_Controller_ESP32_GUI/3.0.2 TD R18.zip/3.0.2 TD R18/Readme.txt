
**************************************Release Note******************************************
This Package is for receiver TDR18 firmware update. 
                                                        

Release Note
❶ Firmware Version:【3.0.2】
--------------------------------------------------------------------------------------------------------------------
1. Fixed the issue of inaccurate ampere telemetry working with the current sensor in the specific hardware version.


❷ History Notes
Firmware Version: 【v1.0.12】
--------------------------------------------------------------------------------------------------------------------
1. Fixed the issue of missing telemetry working above 25mW RF power in EU mode.
--------------------------------------------------------------------------------------------------------------------
Firmware Version: 【1.0.11】
--------------------------------------------------------------------------------------------------------------------
1. Fixed the issue of incorrect behavior of the Xact servo working in FBUS mode once powering on the receiver.
2. Added the support of telemetry data transmission through 2.4G link in the TD mode (The telemetry via 2.4G link can be also achieved under sufficient range with the RF power settings above 25mW in EU mode). 
Note: Please ensure the firmware of TD capable RF module is updated to the latest version.
--------------------------------------------------------------------------------------------------------------------
Firmware Version: v1.0.8
--------------------------------------------------------------------------------------------------------------------
1. Added the 25mW option of the telemetry power. (The telemetry power of 2.4G and 900M bands is synchronized while the option is selected.)
--------------------------------------------------------------------------------------------------------------------



Note: Please update the firmware of all your radios with TD module and receivers accordingly.
-------------------------------------------------------------------------------------------------------------------
How to update internal module TD ISRM:
By radio (SD card) :
1. Put the firmware under the folder [FIRMWARE] of sd card.
2. Power on the radio and find the firmware,select it by press [ENT].
3. Select 'Flash int. module', wait to end.

How to update Tandem receiver by OTA(Over The Air):
1. For ETHOS radios, go to the [File manager], and select the FW
2. Press the enter button, select [Flash RX by int.OTA].
3. Power on the receiver, select the RX, go to the [ENTER], complete the flash process
4. The transmitter will display [Success]. 
5. Wait for 3 seconds,the receiver works properly at the moment.

---------------------------------------------------------------------------------------------------------------------
More details please check FrSky website:
https://www.frsky-rc.com/product-category/receivers/2-4ghz900mhz-td/

**********************All rights reserved to FrSky Electronic ., Ltd.*********************************
 